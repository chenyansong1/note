#!/bin/bash


ifcfg_name=`ip addr|grep '^[0-9]'|grep -vE "lo|virbr"|sort|head -1|awk -F ":| " '{print $3}'`
#echo $ifcfg_name

#remove ifcfg file
ls /etc/sysconfig/network-scripts/ifcfg-*|grep -Ev "lo|back"|xargs rm -f 



real_ifcfg_file="/etc/sysconfig/network-scripts/ifcfg-$ifcfg_name"
first_ifcfg_file=$real_ifcfg_file
second_ifcfg_file=$real_ifcfg_file:1

#modify file
cp /etc/sysconfig/network-scripts/ifg-back $first_ifcfg_file
sed -i '/^NAME=/c NAME='$ifcfg_name'' $first_ifcfg_file
sed -i '/^DEVICE=/c DEVICE='$ifcfg_name'' $first_ifcfg_file



cp /etc/sysconfig/network-scripts/ifg-back $second_ifcfg_file
sed -i '/^NAME=/c NAME="System '${ifcfg_name}':1"' $second_ifcfg_file
sed -i '/^DEVICE=/c DEVICE='$ifcfg_name:1'' $second_ifcfg_file
sed -i '/^IPADDR=/c IPADDR=192.168.10.110' $second_ifcfg_file


service network restart

