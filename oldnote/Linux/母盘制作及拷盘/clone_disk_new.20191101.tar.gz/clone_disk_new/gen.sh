#!/bin/bash

/home/clone_disk_new/mksdb.sh

/home/clone_disk_new/mkosb.sh

