#!/bin/sh
#
#

fdisk /dev/sdb <<_EOT
d
1
d
2
d
3
d
4
d
n
p
1

+500M
n
p
2


a
1

t
2
8e
w
_EOT

