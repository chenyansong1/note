echo "make system"
echo "============ Format sdb1 ==============="
mkfs.ext3 /dev/sdb1
mkfs.ext3 /dev/sdb2
echo "============ Format sdb3 ==============="
mkfs.ext3 /dev/sdb3

mount /dev/sdb2 /mnt -o rw,acl

#mount /dev/sdb3 /mnt 

cd /mnt
mkdir boot
mkdir var
mkdir mnt
mkdir proc
mkdir sys
mkdir dev
mkdir home
mkdir -p usr/local/pgsql/data

mount /dev/sdb1 /mnt/boot
mount /dev/sdb3 /mnt/usr/local/pgsql/data

mkdir /mnt/var/lock
mkdir /mnt/var/run
echo "cp -r -p /[a-c]* /mnt"
cp -r -p /[a-c]* /mnt
echo "cp -r -p /[e-g]* /mnt"
cp -r -p /[e-g]* /mnt
echo "cp -r -p /home /mnt"
cp -r -p /home /mnt
echo "cp -r -p /lib /mnt"
cp -r -p /lib /mnt
echo "cp -r -p /lib64 /mnt"
cp -r -p /lib64 /mnt
echo "cp -r -p /media /mnt"
cp -r -p /media /mnt
echo "cp -r -p /misc /mnt"
cp -r -p /misc /mnt
echo "cp -r -p /net /mnt"
cp -r -p /net /mnt
echo "cp -r -p /opt /mnt"
cp -r -p /opt /mnt
echo "cp -r -p /root /mnt"
cp -r -p /root /mnt
echo "cp -r -p /sbin /mnt"
cp -r -p /sbin /mnt
echo "cp -r -p /selinux /mnt"
cp -r -p /selinux /mnt
echo "cp -r -p /srv /mnt"
cp -r -p /srv /mnt
echo "cp -r -p /tmp /mnt"
cp -r -p /tmp /mnt
echo "cp -r -p /usr /mnt"
cp -r -p /usr /mnt
echo "cp -r -p /var /mnt"
cp -r -p /var /mnt

echo "============ grub-install ============"
grub-install --recheck /dev/sdb  --root-directory=/mnt

cd
cp /root/servercopy/grub.conf /mnt/boot/grub/
cp /root/servercopy/fstab /mnt/etc/
rm -rf /mnt/etc/udev/rules.d/70-persistent-net.rules
chmod -R 777 /mnt/tmp
#rm -rf /mnt/root/servercopy*
umount /mnt/boot
umount /mnt/usr/local/pgsql/data
umount /mnt
