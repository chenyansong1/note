#!/bin/sh
#
#

fdisk /dev/sdb <<_EOT
d
1
d
2
d
3
d
4
d
5
n
p
1

+512M
n
p
2

+100G
n
p
3


p
t
2
82
w
_EOT
sleep 10


